#ifndef COLOR_H
#define COLOR_H

struct Color {
    int r, g, b;

    Color(int red = 0, int green = 0, int blue = 0)
        : r(red), g(green), b(blue) {}

    int getR() const { return r; }
    int getG() const { return g; }
    int getB() const { return b; }
};

#endif