#include "Color.h"
// No implementation needed; struct is self-contained